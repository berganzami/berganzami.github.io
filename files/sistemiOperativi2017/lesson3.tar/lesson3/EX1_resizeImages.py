import os
import sys

if len (sys.argv) == 3:
	stringa=sys.argv[1]
	percent=sys.argv[2]
else: 
	print 'usage: python scriptname.py directoryname percent'
	sys.exit()

for miofile in os.listdir(stringa):
	if '.TIFF' in miofile:
		miofile2 = stringa + miofile
		percento = percent + '%'
		command = 'convert -resize ' + percento + ' ' + miofile2 + ' ' + miofile[:-5] + '_small' +'.TIFF' 
		print stringa+miofile

		os.system(command)

