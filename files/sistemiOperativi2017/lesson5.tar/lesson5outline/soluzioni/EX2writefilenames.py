import os
import sys

if len (sys.argv) == 2:
	cartella=sys.argv[1]
else: 
	print 'te sei sbajato'
	print 'usage: python scriptname.py directoryname'
	sys.exit()

print '\n nella cartella '+cartella+' si trovano i seguenti file: \n'

#correggo l'eventuale errore dovuto al fatto che il percorso specificato non finisce in '/':

if cartella[-1] !='/':
	cartella+='/'

for miofile in os.listdir(cartella):

	stringa = cartella + miofile
	if os.path.isfile(stringa) and miofile[0]!='.': 

# '.' (la cartella presente) compare per difetto nella lista dei contenuti di una cartella: evito di stamparlo

		print miofile

