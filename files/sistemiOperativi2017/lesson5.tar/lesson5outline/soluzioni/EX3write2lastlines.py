import os
import sys

if len (sys.argv) == 2:
	cartella=sys.argv[1]
else: 
	print 'te sei sbajato'
	print 'usage: python scriptname.py directoryname'
	sys.exit()

print '\n sto guardando nella cartella '+cartella+'. \n'

#correggo l'eventuale errore dovuto al fatto che il percorso specificato non finisce in '/':
if cartella[-1] !='/':
	cartella+='/'

for miofile in os.listdir(cartella):

	stringa = cartella + miofile
	if os.path.isfile(stringa)  and miofile[-4:] == '.txt': 

		#prima leggo il file e mi salvo le due ultime righe
		myfile=open(stringa,'r')

		rigaprec=''
		rigaprecprec=''

		for line in myfile:
			rigaprecprec=rigaprec
			rigaprec=line[:]

	
	#adesso apro un nuovo file chiamato X_alt.txt, se il file che sto leggendo si chiama X.txt
	#e stampo le due ultime righe

		nomealt=miofile[:-4] + '_alt.txt'

		myfilealt=open(cartella+nomealt,'w') #l'errore piu' comune e' scrivere: >myfilealt=open(nomealt,'w')
		myfilealt.write(rigaprecprec)
		myfilealt.write(rigaprec)

	#chiudo entrambi!
		myfile.close() 
		myfilealt.close() 
	


