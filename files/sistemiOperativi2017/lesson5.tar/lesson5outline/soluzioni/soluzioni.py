
# coding: utf-8

# # SOLUZIONE di EX1: una funzione che fa la differenza finita. il primo argomento è la stringa del file 
# #del quale voglio calcolare la differenza finita. il secondo argomento è l'indice della colonna 

# In[1]:


def finiteDifference(stringa,colonna):
    f=open(stringa,'r')
    riga0=f.readline()
    lista=riga0.split(' ')
    xa=float(lista[colonna])
    for riga in f:
        lista=riga.split(' ')
        x=float(lista[colonna])
        d=x-xa
        xa=x
        print d

    f.close


# In[3]:


#provo il mio script con il file 'texts/BinderL128.dat'
#(notate che la 1a colonna corrisponde, così come sta scritta la funzione, all'argomento colonna=0)
finiteDifference('texts/BinderL128.dat',2)


# # SOLUZIONE di EX2: ordino una lista mediante il metodo chiamato "insertion-sort"
# #di fatto, è un metodo il cui tempo di computazione cresce con O(n) nel migliore dei casi (liste ordinate o quasi-ordinate)
# #ma è O(n**2) nel peggiore (una lista ordinata in ordine inverso) o nel caso medio-random (come potete verificare con il notebook 'timeTestSortFunctions.ipynb')

# In[4]:


#this is insertion-sort. it is O(n) in the best case
#(but O(n**2) in the worst (inverse order) and average case)
def ordina_3(l):
    aux=l[:]  #mi faccio una copia
    for i in range(len(aux)):  #sposto il pivot (i) a sinistra
        j=i                    #cerco di portare la coppia j,j-1 il più a sinistra possibile
                               #il motivo per cui questo algoritmo è O(n) nel caso migliore è che
                               #mi fermo quando non c'è più bisogno

        while   j>0 and aux[j] < aux[j-1]:
            aux[j] , aux[j-1] = aux[j-1] , aux[j]
            j-=1
    return aux


# In[6]:


#la metto alla prova
import random
listaprova=random.sample(range(1000),1000) #una permutazione della lista range(1000)

ordina_3(listaprova) == range(1000)


# In[ ]:


# !! bravissimo


# # Soluzione di EX5: merge-sort

# In[7]:


#definisco le funzioni merge() e quella ricorsiva, mergesort():

def merge(l1,l2):
    result=[]

    while l1 != [] and l2 != []:
        e1=l1[0]
        e2=l2[0]
        if e1<e2:
            result.append( e1 )
            l1.pop(0)
        else:
            result.append( e2 )
            l2.pop(0)

# i "consume" the rest of the elements of l1,2, if any
    while l1 != []:
        result.append( l1.pop(0) )
    while l2 != []:
        result.append( l2.pop(0) )
    return result


def mergesort(lista):
    M=len(lista)
    if M <2:
        return lista

    l1=lista[:M/2]
    l2=lista[M/2:]

    l1=mergesort(l1)
    l2=mergesort(l2)

    return merge(l1,l2)


# In[23]:


#metto alla prova merge():
l1=[i for i in range(200) if i%2==0] #200 primi numeri pari
l2=[i for i in range(200) if i%2==1] #200 primi numeri dispari
merge(l1,l2) == range(200)


# In[ ]:


#bravissimo!


# In[ ]:


#adesso metto alla prova la funzione mergesort(), come prima


# In[9]:


listaprova=random.sample(range(1000),1000) #una permutazione della lista range(1000)

mergesort(listaprova) == range(1000)


# In[ ]:


#bravissimo!


# In[ ]:


#mi raccomando, fate [se volete] la prova di tempo per verificare che mergesort() è più veloce di ordina_3()


# # Soluzione di EX6: una funzione ricorsiva che crea tutte le combinazioni comb(M,n)

# In[19]:


#definisco la funzione ricorsiva:

def scegli(M,n,lista,listaglobale):
    for j in range (M,0,-1): # M, M-1 , ... , 1
        lista[n-1]=j         # riempio l'ultimo elemento della lista con ogniuno dei j 
        if n>1:              # se non ho finito, lo ripeto con la parte a sinistra della lista
            lista,listaglobale=scegli(j-1,n-1,lista,listaglobale)
        else:
            listaglobale.append(lista[:]) #ATTENZIONE. Devo mettere da parte UNA COPIA della lista 'lista'
                             # fino a che n=0, a quel punto la aggiungo alla lista delle permutazioni fatte
    return lista,listaglobale


# In[20]:


#e, per comodita', un'altra che la lancia

def Scegli(M,n):
    return scegli(M,n,range(n),[])[1] # mi da' il secondo risultato, [1], di scegli(), cioe' la lista globale


# In[21]:


#mettiamola alla prova:

Scegli(6,3)


# In[22]:


#sembra corretto. il loro numero, quant'è? Vediamo:
len(Scegli(10,5) ) == 10*9*8*7*6/(5*4*3*2)


# In[ ]:


# sembra ok 

