def ordina(l):
	aux=[]
	for e in l:
		k=0
		for a in aux:
			if a > e:
				break
			k+=1
		aux.insert(k,e)
	return aux


def ordina_2(l):
	aux=l[:]
	for i in range(len(aux)):
		for j in range(i):
			if aux[i] < aux[j]:
				aux[i] , aux[j] = aux[j] , aux[i]
	return aux

def ordina_3(l):
	aux=l[:]
	for i in range(len(aux)):
		for j in range(i):
			if aux[i-j] < aux[i-j-1]:
				aux[i-j] , aux[i-j-1] = aux[i-j-1] , aux[i-j]
			else:
				break
	return aux

