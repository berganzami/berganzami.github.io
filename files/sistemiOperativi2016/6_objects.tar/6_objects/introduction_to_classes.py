#############################
# A tiny introduction to the notion of classes in Python.
# One illustrates it with the creation and usage of two simple classes, the first one is a set class (in the module 'testClass.py'), endowed with functions allowing the addition of elements to the set, the union and intersection of sets (of class instances). The second one is a complex-number class (in the module 'myComplex.py'). 
# 6th lesson of the course 'Sistemi Operativi', Laurea Triennale in Matematica
# Universita' di Roma, "La Sapienza"
# academic year 2016-2017  
# miguel.berganza@roma1.infn.it
#############################

import testClass
from testClass import testClass


	# class instances are initialized this way:

x=testClass('pippo1')
y=testClass('pippo2')

	# si possono usare funzioni della classe
x.funzioneSciocca()
	# che e' equivalente a (e' questo il significato del primo argomento delle class functions, spesso chiamati 'self')
testClass.funzioneSciocca(x)

	# proviamo le funzioni della classe:
x.aggiungi(['a','b'])
y.aggiungi(['b','c'])
	# e le operazioni + e -
print x+y
print x-y

	#ora, la lista 'lista' e' comune a tutte le istanze, non cosi' la variabile 'ilista'
x.lista.append('m')	
y.lista.append('n')	
print x.lista



# Some exercises
###################################################
# EX1. Complete the complex number class in the module myComplex.py. You can compare it with the complex module cmath: https://docs.python.org/2/library/cmath.html
# Ex2. Modify the class testClass so that also elements of numpy arrays can be added to the set 
###################################################



