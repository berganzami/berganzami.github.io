import numpy as np

class complesso:
	def __init__(self,real,imaginary=0.):
		self.r=real
		self.i=imaginary

	def somma(self,c):
		# simple sum
		return complesso(self.r+c.r,self.i+c.i)


	def __add__(self,altro):
		'''overloading the + operator'''
		# this deals also with sums between reals and complex
		# through the built-in function 'isinstance' 
		if isinstance(altro,complesso):
			return complesso( self.r+altro.r , self.i+altro.i )		
		else:
			return complesso(self.r + altro,self.i)
			

	def modulo(self):
		return np.sqrt(self.r**2+self.i**2)

	def __str__(self):
		'''this is used to print the class instances'''
		return str(self.r) + ' + i ' + str(self.i)

