class testClass:			# a propotype class for a set
	
	lista=[]			# a class variable

	def funzioneSciocca(self):	# a class function
		print "blabla"

	def __init__(self,nome):
		self.ilista=[]		# an instance variable
		self.nome=nome

	# adding elements to the set.
	# it allows set addition:
	def aggiungiGeneral(self,elemento): 
		if elemento not in self.ilista:
			self.ilista.append(elemento)

	# it adds only the elements of its (set) arguments
	# we use the built-in function isinstance()
	# and recursivity!
	def aggiungi(self,elemento): 
		if isinstance(elemento,list):
			 for e in elemento:
				self.aggiungi(e)  # it recursively flattens sets of sets... into single elements
				#self.ilista.append(e) # or it simply appends the elements
		else:
			
			if elemento not in self.ilista:
				self.ilista.append(elemento)


	def __add__(self,c):
		'''overloading the + operator to create SET UNION'''
		mylista=c.ilista[:]
		for e in self.ilista:
			if e not in c.ilista:
				mylista.append(e)
		nuovo=testClass(self.nome +'+'+ c.nome)
		nuovo.ilista=mylista
		# 'nuovo' is a new instance of 'testClass' such that its name is the concatenation of its parents' names and that its list is the intersection beween the parents' lists
		return nuovo



	def __sub__(self,c):
		'''overloading the + operator to create SET INTERSECTION'''
		mylista=[]
		for e in self.ilista:
			if e in c.ilista:
				mylista.append(e)
		nuovo=testClass(self.nome +'-'+ c.nome)
		nuovo.ilista=mylista
		return nuovo

	def __str__(self):
		'''this is used to print the class instances'''
		return str(self.ilista)

