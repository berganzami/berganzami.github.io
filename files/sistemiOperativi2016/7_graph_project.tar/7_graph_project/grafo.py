
import numpy as np
import numpy.random as rnd

class grafo:

	def __init__(self,N=0): 	#initializes a graph with zero nodes and links
#		self.am=[[0 for _ in range(N)] for _ in range(N)]	# adjacency matrix
		self.vicini=[ [ ] for _ in range(N) ]			# a list of void lists (the list of neighbors)
		self.comp=[]
		self.visitato=[0 for _ in range(N)]

	def random(self,k):	#initializes a random graph with average degree k
		N=len(self.vicini)
		K=int(k*N/2.)
		for t in range(K):
			i=int(N*rnd.random())
			j=i
			while j is i or j in self.vicini[i]: #QUESTION: why not taking simply 'j in range(i)'?
				j=int(N*rnd.random())
			self.vicini[i].append(j)
			self.vicini[j].append(i)


	def adjacencyMatrix(self):	#computes the adjacency matrix of a graph
		N=len(self.vicini)
		self.am=[[0 for _ in range(N)] for _ in range(N)]
		for i in range(N):
			for vicino in self.vicini[i]:
				self.am[i][vicino]=1

	def distribuzioneGrado(self,nbins=15):
		degrees=[len(lvicini) for lvicini in self.vicini]
		mybins=[i+0.01 for i in range(16)]
		h,x = np.histogram(degrees,mybins,density=True)
		center =  x[1:] 
		return center, h



	def cercaComponente(self,i): # it looks for a connected component from site i 
		self.visitato[i]=1
		self.comp.append(i)  # this should be void before calling the function
		for v in self.vicini[i]:
			if not self.visitato[v]:
				grafo.cercaComponente(self,v)


	def countConnectedComponents(self):
		N=len(self.vicini)
		self.visitato=[0 for _ in range(N)]
		
		ncomp=[]
		for i in range(N):
			if not self.visitato[i]:
				self.comp=[]
				grafo.cercaComponente(self,i)
				ncomp.append(len(self.comp))

		self.visitato=[0 for _ in range(N)]
		return ncomp

