#############################
# A small project on random graph theory in Python, for pedagogycal purposes.
# It may serve as a simple illustration of the usage of objects and classes, and of recursion.  
# One generates an instance of the 'grafo' class, creating a random graph and verifying that its degree distribution is Poissonian. Afterwords, one counts its connected components (through a recursive function defined in the class), verifying that its number coincides with n-1 where n is the number of null eigenvalues of the Laplacian matrix of the graph. Afterwards, one verifies the graph percolation threshold for random graphs: if their average degree is k>1, there is one giant component in the limit of large number of nodes.
# 7th lesson of the course 'Sistemi Operativi', Laurea Triennale in Matematica
# Universita' di Roma, "La Sapienza"
# academic year 2016-2017  
# miguel.berganza@roma1.infn.it
#############################

import numpy as np
from scipy import special
import matplotlib.pyplot as plt

from grafo import *




# we want first to verify, as a minimal check, that the degree distribution of the random graph is Poissonian
#########################################
def poisson(x,l):
	return np.power(l,x)*np.exp(-l)/special.gamma(x+1)

	# I initialize three random graphs of increasing size and compute their degree distribution:

G1=grafo(100)
G2=grafo(1000)
G3=grafo(10000)

myavdegree=4

G1.random(myavdegree)
G2.random(myavdegree)
G3.random(myavdegree)

x,his1=G1.distribuzioneGrado()
x,his2=G2.distribuzioneGrado()
x,his3=G3.distribuzioneGrado()

plt.plot(x,his1,'.-',label='100',ms=10.)
plt.plot(x,his2,'+-', label='1000',ms=10.)
plt.plot(x,his3,'o',label='10000',ms=10.)

	# I compare them with the poisson distribution
xpoisson=np.arange(0.,max(x),max(x)/100.)
plt.plot(xpoisson,poisson(xpoisson,myavdegree),'-',label='Poisson',lw=2.)
#########################################



# We want to count the size of the larger connected component of a random graph for several values of the average degree

# In particular, we want to illustrate the fact that a random graph with average degree k>1, in the limit of infinite number of sites, is such that the probability of two random points of the graph belonging to the same connected component is one, and vice-versa. See, for example, "Statistical Mechanics of Complex Networks", R. Albert and A. L. Barabasi, Rev. Mod. Phys. 74, 47 (http://arxiv.org/abs/cond-mat/0106096).
#########################################


	# usiamo la funzione countConnectedComponents() che a sua volta usa la funzione ricorsiva cercaComponente(). La ricorsivita' e' una risorsa per cui una funzione puo' chiamare se' stessa. Un esempio e' la funzione fattoriale:
def factorialRecursive (n):
	if n is 1:
		return 1
	else:
		return factorialRecursive(n-1)*n

	# l'utilizzo della ricorsivita' in Python non e' molto comune ne' particolarmente efficente. Per una volta (e per motivi didattici) lo useremo. Per i nostri scopi ci conviene alzare il limite delle volte che una funzione puo' chiamare ricorsivamente se stessa. Si incrementa cosi':

import sys
sys.setrecursionlimit(20000)


#########################################
	# la misura della taglia della componente connessa maggiore:

klist=np.arange(0.,2.,0.1)

Nlist=[100,1000,10000]

nrealizations=20

for N in Nlist:
	fractionGiant=[]
	for k in klist:
		fraction=0.
		for r in range(nrealizations):
			G=grafo(N)
			G.random(k)
			taglie=G.countConnectedComponents()
			taglie.sort()
			fraction+=1.*taglie[-1]/(1.*N)
		fraction/=nrealizations
		fractionGiant.append(fraction)
	
	plt.plot(klist,fractionGiant,'.-')

#########################################




# SOME EXERCISES: ######################################
#########################################

# EX1. Una domanda un poco sottile: come mai non abbiamo usato un semplice loop in j, come: 'for j in range(i)' al posto del loop 'while j is i or j in self.vicini[i]' nella creazione della funzione 'random' della classe 'grafo'?

# EX2. Confrontare il risultato della funzione countConnectedComponents() con il cosiddetto metodo spettrale: il numero di autovalori nulli della matrice laplaciana e' =n+1 ove n e' il numero di componenti connesse del grafo (vide, v.g., Anderson Jr, W. N. and T. D. Morley, 1985: Eigenvalues of the laplacian of a graph. Linear and multilinear algebra, 18 (2), 141–145).
#########################################
