#############################
# some functions of the Python 'numpy' and 'matplotlib' modules
# 4rd lesson of the course 'Sistemi Operativi', Laurea Triennale in Matematica
# Universita' di Roma, "La Sapienza"
# academic year 2016-2017  
# miguel.berganza@roma1.infn.it
#############################

# the module 'numpy'
# see	https://docs.scipy.org/doc/numpy/index.html
#########################################################
import numpy as np
	# np presents many variable types, absent in standard Python. 
y = np.float32([1,2,4])
	# the types, however, are preserved in equalities 

# 'numpy' arrays
#########################################################
	# numpy provides arrays, these are some functions to initialize them:
a=np.zeros(shape) # where 'shape' is a tuple specifying the number of elements in each dimension, v.g. (3,1,2)
	# the type can also been specified
a=np.zeros(shape,dtype='int8')
	# a different way of initialize them is with 'arrange' (x0,xf,dx are initial, final, and interval)
a=np.arange(x0,xf,dx,dtype=np.float)

	# a further method: from an existing Python list
lista=[[ i-j for i in range(10)] for j in range (10)]
a=np.array(lista,dtype='float16')

	# multi-dimensional array element can be accessed with commas: a[0,0]
	# but out-of-bounds indices give an error

	# the shape of an array can be accessed with 'shape'
np.shape(a) # or 'a.shape'

	# arrays can be easily reshaped: 
y = np.arange(35).reshape(5,7)
	# the slicing syntaxis is still allowed: check, for instance, y[1:5:2,::3]

	#one can access a set of elements of an array using an index array or an index list:
x = np.arange(0, 50, 10)
x[np.array([1, 3])]  # x[[1, 3]]

	# find much more on indexing in https://docs.scipy.org/doc/numpy/user/basics.indexing.html 

	# assignment values in arrays: one can assign an index subset to a constant 
y[:,3:6]=-1 	# c.f. 'y' in the example below
	# or to a correctly-shaped array:
y[:2,3:6]=np.arange(-3,0)
y[:3,3:6]=np.zeros((3,3))

	# simple operations ( + - * / ) between numpy arrays is element-wise. Scalar-arrays operations are also permitted. Two array dimensions are compatible if they are equal, or if one of them is 1:

z1 = np.arange(4).reshape(4,1)
z2 = np.ones(5)
(z1+z2).shape

#########################################################



