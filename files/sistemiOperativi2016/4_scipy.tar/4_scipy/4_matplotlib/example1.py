import matplotlib.pyplot as plt
import numpy as np

#numeri distribuiti normalmente
#########################################
sample = np.random.normal(loc=10., scale=5., size=10000)

#creo un istogramma:
#########################################
Y, X = np.histogram(sample,bins=20,density=True)
X = (X[1:]+X[:-1])/2.

#semplice plot:
#########################################
plt.plot(X, Y, '.-b')
plt.savefig('figure1_simple.pdf')

	#in ipython one can visualize a figure like this: #plt.show()


#un plot piu' sofisticato:
#########################################
plt.semilogy(X, Y, '.-g', label=r'$P(x)$', ms=10, lw=2, alpha=.8)

plt.xlabel(r'x', size=22)
plt.ylabel(r'P(x)', size=22)

plt.xticks(size=15)
plt.yticks(size=15)

plt.legend(loc=3, fontsize=22)
#plt.gcf().set_size_inches(12, 9)
plt.savefig('figure1.pdf')
 
plt.close()

