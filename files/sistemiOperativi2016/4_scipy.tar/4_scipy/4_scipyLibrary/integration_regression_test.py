#############################
# A very basic example of the usage of the SciPy library  
# 4th lesson of the course 'Sistemi Operativi', Laurea Triennale in Matematica
# Universita' di Roma, "La Sapienza"
# academic year 2016-2017  
# miguel.berganza@roma1.infn.it
#############################


import scipy.integrate as integrate
import numpy as np
from numpy import sin, cos, exp, pi, inf , sqrt , abs, log



# An example of the use of the function scipy.integrate.quad in module 'scipy.integrate'
#####################################

	# I define the integrand
def gauss(x,s=1.):
	return exp(-x**2./(2.*s**2))

	# I evaluate the integral over -\infty and +\infty:
	# and compair it with its exact value
def normGauss(s):
	I = integrate.quad(gauss,-inf,inf,args=(s))
	# the output is a tuple with: (result, errorUpperBound)
	return I[0]-sqrt(2.*pi)*s , I[1]



# some sample functions to test numerical quadrature routines:
#####################################

	#We use the equation: \int_0^{\pi/2} \sin^2 = \pi/4
def integrand1(x):
	return sin(x)**2

	# and \int_0^{1} \sqrt(1-x**2) = \pi/4
def integrand2(x): 
    return (1.-x**2)**(0.5)

	# and \int_0^{2\pi} (2+sin(x))^{-1} = 2\pi/\sqrt{3}
def integrand3(x): 
    return (2.+sin(x))**(-1.)

	# simple polynome 
def integrand4(x): 
    return (x)**(4)

	# An example of the use of the function scipy.integrate.simps
	# in particular: a function that outputs the absolute value of the error in a desired interval
def simpsonsEfficiency(n):
	a=0.
	b=1.
	dx=(b-a)/n
	x=np.arange(a,b+dx,dx)
	y=integrand4(x)
	return abs (integrate.simps(y,x)-1./5.)




# una semplice verifica dell'andamento dell'errore secondo le funzioni di quadratura Simpsons e Trapezoidal che ho scritto (in un file 'mysimpson.py', non riportato):
# faccio una regressione lineare del logaritmo dell'errore commesso dalla funzione di integrazione numerica rispetto del logaritmo del numero di intervalli usati. 
####################################

import mysimpson

	# prima costruisco delle liste con l'errore come funzione di n (il numero di intervalli), per vari n's
	# la mia funzione (che vi incoraggio a scrivere da voi) si chiama mySimpson()
x=np.arange(4,1000,32)	# questa e' la lista degli n's
y1=[abs(mysimpson.mySimpson(integrand4,0.,1.,i)-1./5.) for i in x]
y2=[abs(mysimpson.myTrapezoidal(integrand4,0.,1.,i)-1./5.) for i in x]
	# vedo che aspetto ha l'errore come funzione di n (ricordate: per vedere il risultato di un plot fate 'plt.show()' ):
plt.loglog(x,y1,'.b',x,y2,'.g',1000.*pow(x,-4.),'-b',1000.*pow(x,-2.),'-g')


	# REGRESSIONE LINEARE:
	#########################################
	# per vedere la potenza del decadimento, faccio un fit (una regressione) lineare, usando la funzione 'curve_fit' del modulo 'scipy.optimize'

from scipy.optimize import curve_fit
from numpy import log

	# voglio fare la regressione con una funzione lineare, dunque: 
def func(x,a,b):		
	return a*x+b
	# il primo argomento di ritorno della funzione 'curve_fit' (c.f. la sua descrizione su 'https://docs.scipy.org/') e' una lista con i parametri:
[a1,b1]=curve_fit(func,log(x),log(y1))[0]
[a2,b2]=curve_fit(func,log(x),log(y2))[0]
	# comparo dunque il risultato dell'errore 'y1' e 'y2' nei casi Simpson e Trapezoidal rispettivamente, con i risultati dei fit:
plt.plot(log(x),log(y1),'.b',log(x),log(y2),'.g',log(x),a1*log(x)+b1,'-b',log(x),a2*log(x)+b2,'-g')
	#########################################


###############################################################
# ESERCIZI
# E1. Scrivete le vostre funzioni 'mySimpson()' e 'myTrapezoidal()', che integrano numericamente una funzione in un intervallo desiderato con i metodi 'composite Simpson' e 'composite Trapezoidal'. Verificate, usando un metodo simile a quello usato in questo documento (o usando le stesse istruzioni) che l'errore della vostra funzione d'integrazione Simpson, come funzione del numero, n, di intervalli, decresce non piu' lentamente di n^-4, e che l'errore della vostra funzione d'integrazione Trapezoidal decresce non piu' lentamente di n^-2, per i casi delle funzioni di prova 1,3,4 di qui sopra. 

# E2. Nel caso della funzione 'integrand2', come decresce l'errore delle funzioni di integrazione? Non sembra questo risultato essere in disaccordo con la regola di convergenza dell'errore nel caso di entrambi i metodi? Provvedete una spiegazione.

# E3. Nel caso della funzione 'integrand1', il metodo di Simpson sembra avere un errore nullo per ogni valore n>=4, n%2==0. Come mai?


###############################################################

# Alcune proposte di esercizi piu' generali:
###############################################################
# E4. Programmate una funzione che costruisca un istogramma con dei bin equispaziati, data una lista (o un numpy.array) con i dati e dato il numero di bins. Confrontate il risultato con la funzione numpy.histogram ( https://docs.scipy.org/doc/numpy/reference/generated/numpy.histogram.html )

# (c.f.) anche il prossimo capitolo, su numeri complessi

# E5. Programmate una funzione che, prendendo come argomento una coppia di liste (o numpy.array), X, Y, e un numero x, effettua un'interpolazione lineare del valore di Y in x. Potete confrontare il risultato con la funzione scipy.interpolate.interp1d ( https://docs.scipy.org/doc/scipy/reference/generated/scipy.interpolate.interp1d.html#scipy.interpolate.interp1d ) 

# E6. Programmate una funzione che effettua la regressione lineare di un set di dati, X, Y. Potete confrontarvi con la funzione scipy.optimize.curve_fit ( https://docs.scipy.org/doc/scipy/reference/generated/scipy.optimize.curve_fit.html#scipy.optimize.curve_fit ), oppure con la piu' semplice scipy.stats.linregress ( https://docs.scipy.org/doc/scipy-0.14.0/reference/generated/scipy.stats.linregress.html )

###############################################################

